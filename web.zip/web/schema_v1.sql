drop database IF EXISTS hospital_app;
create database hospital_app;
use hospital_app;

drop TABLE IF EXISTS `hospitals`;
create table hospitals(
id int AUTO_INCREMENT primary key,
name varchar(200)unique,
reg_no varchar(250),
other_no varchar(250),
slogan varchar(250),
address varchar(250),
contact varchar(250),
logo varchar(250),
sender_id varchar(10),
sms_username varchar(100),
sms_pwd varchar(100),
email varchar(150),
package numeric(12,2),
description varchar(200),
is_active int default 1
)Engine=INNODB;

drop TABLE IF EXISTS `doctors`;
create table doctors(
id int AUTO_INCREMENT primary key,
name varchar(200),
mobile_no varchar(10),
is_active int default 1,
hospital_id int,
added_on datetime,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
)Engine=INNODB;

-- create table doctor_services(
-- id int AUTO_INCREMENT primary key,
-- name varchar(100),
-- short_name varhcar
-- )Engine=INNODB;

-- drop table doctor_services;

drop TABLE IF EXISTS `doctor_services`;
create table doctor_services(
id int AUTO_INCREMENT primary key,
doctor_id int,
type enum('OPD','IPD','X-Ray','Pathology'),
fees numeric(10,2),
added_on datetime,
updated_by int,
updated_on datetime,
foreign key(doctor_id) references doctors(id) on update cascade on delete cascade
)Engine=INNODB;


drop TABLE IF EXISTS `schemes`;
create table schemes(
id int AUTO_INCREMENT primary key,
name varchar(50),
charge numeric(12,2),
hospital_id int,
added_on datetime,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
)Engine=INNODB;



drop TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` mediumint(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;


INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User'),
(4, 'doctor', 'doctor'),
(5, 'reception', 'Reception'),
(6, 'medical_examin', 'Medical Examination');

drop TABLE IF EXISTS `employee`;
CREATE TABLE IF NOT EXISTS `employee` (
  id int(11) primary key auto_increment,
  hospital_id int,
  first_name varchar(100)NOT NULL,
  last_name varchar(100)NOT NULL,
  contact varchar(10) NOT NULL,
  contact_emergency varchar(10),
  local_address varchar(200),
  permanent_address varchar(200),
  image varchar(200),
  foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS users;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) primary key auto_increment,
  `emp_id` int(11) NOT NULL, 
   hospital_id int,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,  
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
   role enum('admin','user') NOT NULL DEFAULT 'user',
    authKey varchar(100) NOT NULL,
    accessToken varchar(100) DEFAULT NULL,
  `ip_address` varchar(15) DEFAULT NULL, 
  `created_on` datetime,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `is_password_update` int(11) DEFAULT '0',
  `is_security_update` int(11) DEFAULT '0',
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade,
 foreign key(emp_id) references employee(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS `users_group`;
CREATE TABLE IF NOT EXISTS `users_groups` (
`id` int(11) primary key auto_increment,
`user_id` int(11) NOT NULL,
`group_id` mediumint(8) NOT NULL
) ENGINE=InnoDB;


drop TABLE IF EXISTS `investigation`;
CREATE TABLE IF NOT EXISTS `investigation` (
id int(11) primary key auto_increment,
hospital_id int,
full_name varchar(250),
short_name varchar(50),
fees numeric(12,2),
type enum('XRAY','PATHOLOGY'),
description text,
is_child_table varchar(10) default 'No',
created_by int,
created_at datetime,
updated_by int,
updated_at timestamp,
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;


drop TABLE IF EXISTS `pathology_test`;
CREATE TABLE IF NOT EXISTS `pathology_test` (
id int(11) primary key auto_increment,
investigation_id int,
test varchar(200),
unit varchar(50),
reference_range varchar(50),
test_type varchar(100),
foreign key(investigation_id) references investigation(id) on update cascade on delete cascade
) ENGINE=InnoDB;


drop TABLE IF EXISTS `patient`;
CREATE TABLE IF NOT EXISTS `patient` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
   hospital_id int,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `father_name` varchar(100) NOT NULL,
  `mother_name` varchar(100) NOT NULL,
  `contact_no` varchar(100) NOT NULL,
  `alt_contact_no` varchar(100) NOT NULL,
  `patient_age` int(100) NOT NULL,
  `age_unit` varchar(100) NOT NULL DEFAULT 'year',
  `patient_gender` varchar(100) NOT NULL,
  `blood_group` varchar(200) NOT NULL,
  `rh_type` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `ward_name` varchar(255) NOT NULL,
  `bed` varchar(255) NOT NULL,
  `adhaar_card` varchar(100) NOT NULL,
  `samagra_id` varchar(200) NOT NULL,
  `state` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `address` varchar(250) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `scheme` varchar(100) NOT NULL DEFAULT '1',
  `rfid` varchar(100) DEFAULT NULL,
  `mlc_case` varchar(100) NOT NULL DEFAULT 'No',
  `consultant` varchar(100) NOT NULL,
  `admited_by` varchar(100) NOT NULL,
  `relation_with_patient` varchar(100) NOT NULL,
  `attender_contact` varchar(100) DEFAULT NULL,
  `is_refered` int(11) NOT NULL DEFAULT '0',
  `refered_by` varchar(250) DEFAULT NULL,
  `rejection_reason` varchar(500) NOT NULL,
  `registration_fees` decimal(12,2) DEFAULT NULL,
  `remark` text DEFAULT NULL,
  `addedby` int(11) NOT NULL,
  `entrydt` datetime NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '1',
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;


drop TABLE IF EXISTS `patient_visit`;
CREATE TABLE IF NOT EXISTS `patient_visit` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
   hospital_id int,
   uhid int not null,
   visit_type enum('OPD','IPD','EMERGENCY','DAYCARE','TC') not null,
    mobileno varchar(200),
    relation varchar(200),
    attender varchar(200),
    visit_fees decimal(12,2),
   remark text DEFAULT NULL,
   created_by int not null,
   created_at datetime,
   updated_by int,
   updated_at timestamp,  
  `is_active` int(11) NOT NULL DEFAULT '1',
   foreign key(uhid) references patient(id) on update cascade on delete cascade,
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade

) ENGINE=InnoDB;


drop TABLE IF EXISTS `pro`;
CREATE TABLE IF NOT EXISTS `pro` (
  `id` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
hospital_id int,
   designation enum('Doctor','Advocate','Govt Employee','Business Man','Others'),
   first_name varchar(100),
   last_name varchar(100),
   mobile_no varchar(10),
   email varchar(100),
   address varchar(200),
   comm_type enum('percent','rupees'),
   comm_percent int default 0,
   comm_rupees numeric(12,2) default '0.00',
   remark text DEFAULT NULL,
   created_by int not null,
   created_at datetime,
   updated_by int,
   updated_at timestamp,  
   is_active int(11) NOT NULL DEFAULT '1',
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade

) ENGINE=InnoDB;
  

drop TABLE IF EXISTS `opd`;
CREATE TABLE IF NOT EXISTS `opd` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
hospital_id int,
visit_id int,
uhid int,
doctor_id int,
doctor_fee numeric(12,2),   
other_fee numeric(12,2),   
user_remark text DEFAULT NULL,
dr_remark text DEFAULT NULL,
opd_path int default 0,
opd_xray int default 0,
visit_date date,
visit_time time,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,  
is_active int(11) NOT NULL DEFAULT '1',
foreign key(uhid) references patient(id) on update cascade on delete cascade,
foreign key(visit_id) references patient_visit(id) on update cascade on delete cascade,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS `patient_investigation`;
CREATE TABLE IF NOT EXISTS `patient_investigation` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
hospital_id int,
uhid int,
investigation_id int,
doctor_id int,
doctor_fee numeric(12,2),   
investigation_fee numeric(12,2), 
other_fee numeric(12,2) default '0.00',   
type enum('XRAY','PATHOLOGY'),
description text,
visit_date date,
visit_time time,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,  
is_active int(11) NOT NULL DEFAULT '1',
foreign key(uhid) references patient(id) on update cascade on delete cascade,
foreign key(investigation_id) references investigation(id) on update cascade on delete cascade,
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS `patient_pathology_test`;
CREATE TABLE IF NOT EXISTS `patient_pathology_test` (
id int(11) primary key auto_increment,
patient_investigation_id int,
investigation_id int,
test_value varchar(100),
foreign key(patient_investigation_id) references patient(id) on update cascade on delete cascade,
foreign key(investigation_id) references investigation(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS `patient_documents`;
CREATE TABLE IF NOT EXISTS `patient_documents` (
   id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
   hospital_id int,
   uhid int not null,
   doc_type enum('OPD','IPD','EMERGENCY','DAYCARE','TC') not null,
   filename varchar(255),
   remark text DEFAULT NULL,
   created_by int not null,
   created_at datetime,
   updated_by int,
   updated_at timestamp,  
   is_active int(11) NOT NULL DEFAULT '1',
 foreign key(uhid) references patient(id) on update cascade on delete cascade,
 foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
) ENGINE=InnoDB;


/*IPD tables*/


drop TABLE IF EXISTS `ipd`;
CREATE TABLE IF NOT EXISTS `ipd` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
hospital_id int,
visit_id int,
uhid int,  
user_remark text DEFAULT NULL,
ipd_path int default 0,
ipd_xray int default 0,
admit_date date,
admit_time time,
ipd_status enum('ADMIT','DISCHARGE'),
discharge_type enum('DOR','DISCHARGE','LAMA','DAMA','DC'),
is_bill_clear int,
discharge_date date,
discharge_time time,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,  
is_active int(11) NOT NULL DEFAULT '1',
foreign key(uhid) references patient(id) on update cascade on delete cascade,
foreign key(visit_id) references patient_visit(id) on update cascade on delete cascade,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade

) ENGINE=InnoDB;

drop TABLE IF EXISTS `doctors`;
create table doctors(
id int AUTO_INCREMENT primary key,
name varchar(200),
mobile_no varchar(10),
is_active int default 1,
hospital_id int,
added_on datetime,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade
)Engine=INNODB;

drop TABLE IF EXISTS `ipd_shift`;
drop TABLE IF EXISTS bed;
drop TABLE IF EXISTS ward;
drop TABLE IF EXISTS floor;

create table floor(
id int AUTO_INCREMENT primary key,
hospital_id int,
name varchar(200) unique,
remark varchar(255),
is_active int default 1,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade  
)Engine=INNODB;


create table ward(
id int AUTO_INCREMENT primary key,
hospital_id int,
floor_id int,
name varchar(200) unique,
charges decimal(12,2),
remark varchar(255),
is_active int default 1,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(floor_id) references floor(id) on update cascade on delete cascade,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade  
)Engine=INNODB;


create table bed(
id int AUTO_INCREMENT primary key,
hospital_id int,
ward_id int,
floor_id int,
name varchar(200) unique,
remark varchar(255),
is_active int default 1,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(ward_id) references ward(id) on update cascade on delete cascade,  
foreign key(floor_id) references floor(id) on update cascade on delete cascade,
foreign key(hospital_id) references hospitals(id) on update cascade on delete cascade  
)Engine=INNODB;


CREATE TABLE IF NOT EXISTS `ipd_shift` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
ipd_id int,
floor_id int,
ward_id int,
bed_id int,
remark varchar(255),
admit_date date,
admit_time time,
ipd_charges decimal(12,2),
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(ipd_id) references ipd(id) on update cascade on delete cascade,
foreign key(floor_id) references floor(id) on update cascade on delete cascade,  
foreign key(ward_id) references ward(id) on update cascade on delete cascade,  
foreign key(bed_id) references bed(id) on update cascade on delete cascade  
) ENGINE=InnoDB;

create table ipd_doctor_visit(
id int AUTO_INCREMENT primary key,
ipd_id int,
doctor_service_id int,
fees numeric(10,2),
remark text,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(ipd_id) references ipd(id) on update cascade on delete cascade,
foreign key(doctor_service_id) references doctor_services(id) on update cascade on delete cascade
)Engine=INNODB;

create table procedures(
id int AUTO_INCREMENT primary key,
name varchar(100),
description varchar(255),
type enum('hr','day','unit'),
charge numeric(12,2),
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp
)Engine=INNODB;

create table ipd_procedures(
id int AUTO_INCREMENT primary key,
ipd_id int,
procedure_id int,
qty numeric(3,1),
charge numeric(12,2),
total_charge numeric(12,2),
remark varchar(250),
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,
foreign key(ipd_id) references ipd(id) on update cascade on delete cascade,
foreign key(procedure_id) references procedures(id) on update cascade on delete cascade
)Engine=INNODB;

ALTER TABLE `ward` ADD `charges` DECIMAL(12,2) NULL AFTER `name`;
ALTER TABLE `investigation` CHANGE `updated_at` `updated_at` TIMESTAMP on update CURRENT_TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP;



drop TABLE IF EXISTS `medical_examin`;
CREATE TABLE IF NOT EXISTS `medical_examin` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
uhid int,  
visit_id int,
days int default 1,
type enum('Admit','Discharge'),
bp varchar(200) DEFAULT NULL,
pulse varchar(200) DEFAULT NULL,
temp varchar(200) DEFAULT NULL,
rr varchar(200) DEFAULT NULL,
height varchar(200) DEFAULT NULL,
weight varchar(200) DEFAULT NULL,
pallor varchar(200) DEFAULT NULL,
ict varchar(200) DEFAULT NULL,
pa varchar(200) DEFAULT NULL,
oed varchar(200) DEFAULT NULL,
rs varchar(200) DEFAULT NULL,
cvs varchar(200) DEFAULT NULL,
cns varchar(200) DEFAULT NULL,
gch varchar(200) DEFAULT NULL,
plantor varchar(200) DEFAULT NULL,
pupil varchar(200) DEFAULT NULL,
neck_rigidity varchar(200) DEFAULT NULL,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,  
is_active int(11) NOT NULL DEFAULT '1',
foreign key(uhid) references patient(id) on update cascade on delete cascade,
foreign key(visit_id) references patient_visit(id) on update cascade on delete cascade
) ENGINE=InnoDB;

drop TABLE IF EXISTS `discharge`;
CREATE TABLE IF NOT EXISTS `discharge` (
id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
visit_id int,
uhid int,  
next_followup date DEFAULT NULL,
diagnosis varchar(250) DEFAULT NULL,
general_notes varchar(200) DEFAULT NULL,
investigations text DEFAULT NULL,
findings varchar(200) DEFAULT NULL,
doctor_name varchar(200) DEFAULT NULL,
doctor_date date DEFAULT NULL,
doctor_time time DEFAULT NULL,
operator_name varchar(200) DEFAULT NULL,
operator_date date DEFAULT NULL,
operator_time time DEFAULT NULL,
remark text DEFAULT NULL,
discharge_date date,
discharge_time time,
created_by int not null,
created_at datetime,
updated_by int,
updated_at timestamp,  
is_active int(11) NOT NULL DEFAULT '1',
foreign key(uhid) references patient(id) on update cascade on delete cascade,
foreign key(visit_id) references patient_visit(id) on update cascade on delete cascade
) ENGINE=InnoDB;



ALTER TABLE `ipd` ADD `bill_amt` DECIMAL(12,2) NULL AFTER `is_bill_clear`, ADD `bill_disc` DECIMAL(12,2) NULL AFTER `bill_amt`, ADD `discounted_bill_amt` DECIMAL(12,2) NULL AFTER `bill_disc`;




-------menu_master Table created by pankaj on 07-01-19---------


drop TABLE IF EXISTS `menu_master`;
CREATE TABLE IF NOT EXISTS `menu_master` (
	id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	parent_id int,
	link_name varchar(200) DEFAULT NULL,
	link_url varchar(200) DEFAULT NULL,
	link_short_url varchar(200) DEFAULT NULL,
	link_desc text DEFAULT NULL,
	open_class varchar(200) DEFAULT NULL,   
	active_class1 varchar(200) DEFAULT NULL,
	active_class2 varchar(200) DEFAULT NULL,
	is_active int(11) NOT NULL DEFAULT '1',
	foreign key(parent_id) references menu_master(id) on update cascade on delete cascade
) ENGINE=InnoDB;



drop TABLE IF EXISTS `menu_assignment`;
CREATE TABLE IF NOT EXISTS `menu_master` (
	id int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
	user_id int,
	menu_id int,
	is_active int(11) NOT NULL DEFAULT '1',
	foreign key(parent_id) references menu_master(id) on update cascade on delete cascade
	foreign key(parent_id) references menu_master(id) on update cascade on delete cascade
) ENGINE=InnoDB;

